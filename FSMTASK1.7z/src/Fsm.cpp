#include "pch.hpp"
#include "Fsm.hpp"

void Fsm::SweepUnreachableStates() {
    if (GetStateQuantity() == 0) return;

    std::vector<bool> reachableState(GetStateQuantity());
    *reachableState.begin() = true;

    std::queue<State> q;
    q.push(0);
    unsigned newStateQuantity = 1;

    // find unreachable
    while (!q.empty()) {
        State currentState = q.front(); q.pop();
        for (unsigned entrySignal = 0; entrySignal < GetEntrySignalQuantity(); ++entrySignal) {
            auto const& [state, signal] = GetTransition(currentState, entrySignal);
            if (state.IsOk() && !reachableState[state.Index()]) {
                reachableState[state.Index()] = true;
                q.push(state);
            }
        }
    }

    
}